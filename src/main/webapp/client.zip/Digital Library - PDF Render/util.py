import time


class Book:
    def __init__(self, name, isbn, time_loaned):
        self.name = name
        self.isbn = isbn
        self.time_loaned = int(time_loaned)

    def days_passed(self):
        return (current_milli_time() - self.time_loaned) / (1000 * 60 * 60 * 24)


def current_milli_time():
    return round(time.time() * 1000)
