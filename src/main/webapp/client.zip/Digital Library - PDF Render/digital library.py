import io
import requests
from PyPDF2 import PdfFileWriter, PdfFileReader
from kivy.core.image import Image as CoreImage
from kivy.lang import Builder
from kivy.uix.image import Image
from kivy.uix.screenmanager import *
from kivymd.app import MDApp
import hashlib
import urllib.request
import pdfplumber
from kivymd.uix.button import *
from pdf2image import *
import threading
from AES import *
from util import *
import os

NGROK = True
# URL = 'https://127.0.0.1:8443/Final_Project_war_exploded/'


URL = 'https://98b0-2a10-8003-727b-0-d155-8da2-c859-ad28.ngrok.io/Final_Project_war_exploded/'


class LoginScreen(Screen):
    def login(self):
        self.parent.current = "app"

    def clear(self):
        self.ids.user.text = ""
        self.ids.password.text = ""


class AppScreen(Screen):
    buttons = []

    def enter(self):
        user = self.manager.get_screen("login").ids.user.text
        pw = self.manager.get_screen("login").ids.password.text

        pw = hashlib.sha256(pw.encode()).hexdigest()

        if NGROK:
            r = requests.get(f'{URL}GetLoansServlet?email={user}')
            pieces = r.text.split(';')[:-1]

        else:
            r = urllib.request.urlopen(f'{URL}GetLoansServlet?email={user}')
            pieces = r.read().decode("utf-8").split(';')[:-1]

        books = [Book(pieces[i].split('&')[0], pieces[i].split('&')[1], pieces[i].split('&')[2]) for i in
                 range(len(pieces))]

        f = []
        for (dirpath, dirnames, filenames) in os.walk("files"):
            f.extend(filenames)

        for file_name in f:
            exists = False
            for i in books:
                if i.isbn is file_name.split(".")[0] and not i.days_passed() > 7:
                    exists = True

            if not exists:
                os.remove(f"files/{file_name}")

        offset = 0
        threads = {}
        self.clear_widgets(self.buttons)
        # self.ids.head.text = "Downloading..."
        for i in books:
            days = i.days_passed()
            if i.days_passed() > 7:
                btn = MDRectangleFlatButton(text=f"{i.name}\nyour time ran out", pos_hint={'center_x': 0.3 + offset, 'center_y': 0.3}, padding=5)
                self.add_widget(btn)
                self.buttons.append(btn)

            else:
                if f'{i.isbn}.pdf' not in f or f'{i.isbn}.key' not in f:
                    threads[i] = threading.Thread(target=self.load_doc, args=(i.isbn, user, pw))
                    threads[i].start()

                    offset -= 0.2
                else:

                    btn = MDRectangleFlatButton(text=i.name, pos_hint={'center_x': 0.3 + offset, 'center_y': 0.3},
                                                on_press=self.keypress, padding=5)
                    btn.my_id = i.isbn
                    self.add_widget(btn)
                    self.buttons.append(btn)

            offset += 0.2

        for i in threads:
            threads[i].join()
            btn = MDRectangleFlatButton(text=i.name, pos_hint={'center_x': 0.3 + offset, 'center_y': 0.3},
                                        on_press=self.keypress, padding=5)
            btn.my_id = i.isbn
            self.add_widget(btn)
            self.buttons.append(btn)
            offset += 0.2

        self.ids.head.text = "Choose Book To View"
        self.ids.email.text = user
        self.ids.pw.text = pw

    def load_doc(self, isbn, user, pw):
        with open(f"files/{isbn}.pdf", "wb") as output1:
            if NGROK:
                r = requests.get(f'{URL}BookContentServlet?email={user}&pw={pw}&isbn={isbn}')
                output1.write(r.content)
            else:
                r = urllib.request.urlopen(f'{URL}BookContentServlet?email={user}&pw={pw}&isbn={isbn}')
                output1.write(r.read())

        with open(f'files/{isbn}.key', "wb") as output2:
            if NGROK:
                r = requests.get(f'{URL}BookKeyServlet?email={user}&pw={pw}&isbn={isbn}')
                output2.write(r.content)
            else:
                r = urllib.request.urlopen(f'{URL}BookKeyServlet?email={user}&pw={pw}&isbn={isbn}')
                output2.write(r.read())

    def keypress(self, instance):
        self.manager.get_screen("viewer").ids.isbn.text = instance.my_id
        self.parent.current = "viewer"


class PDFScreen(Screen):
    def enter(self):
        self.ids.page.text = '1'
        self.render_page(1)

    def go_back(self):
        self.parent.current = "app"

    def next(self):
        current = int(self.ids.page.text)
        try:
            self.render_page(current + 1)
            self.ids.page.text = str(current + 1)
        except:
            pass

    def back(self):
        current = int(self.ids.page.text)
        try:
            self.render_page(current - 1)
            self.ids.page.text = str(current - 1)
        except:
            pass

    def render_page(self, page):
        user = self.manager.get_screen("login").ids.user.text
        pw = self.manager.get_screen("login").ids.password.text
        pw = hashlib.sha256(pw.encode()).hexdigest()
        isbn = self.ids.isbn.text

        with open(f"files/{isbn}.key", "rb") as file:
            encrypted_key = file.read()

        if NGROK:
            r = requests.get(f'{URL}KeyKeyServlet?email={user}&pw={pw}&isbn={isbn}')
            key_key = r.text

        else:
            r = urllib.request.urlopen(f'{URL}KeyKeyServlet?email={user}&pw={pw}&isbn={isbn}')
            key_key = r.read().decode("utf-8")

        key = decrypt(key_key, encrypted_key).decode("utf-8")

        with open(f"files/{isbn}.pdf", "rb") as file:
            decrypted = decrypt(key, file.read())

        with open("temp/decrypted.pdf", "wb") as file:
            file.write(decrypted)

        decrypted_file = open("temp/decrypted.pdf", "rb")

        input_pdf = PdfFileReader(decrypted_file)
        output = PdfFileWriter()

        if page > input_pdf.getNumPages() or page < 1:
            decrypted_file.close()
            raise Exception

        output.addPage(input_pdf.getPage(page - 1))

        with open("temp/page.pdf", "wb") as file:
            output.write(file)

        pages = convert_from_path("temp/page.pdf", poppler_path='poppler-0.68.0\\bin')

        pages[0].save("temp/file.jpg", format="JPEG")
        with open("temp/file.jpg", "rb") as file:
            img_bytes = io.BytesIO(file.read())

        decrypted_file.close()
        os.remove("temp/file.jpg")
        os.remove("temp/page.pdf")
        os.remove("temp/decrypted.pdf")

        cim = CoreImage(img_bytes, ext='jpg')

        self.ids.file.texture = cim.texture


class MainApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "BlueGray"
        return Builder.load_file('app.kv')

    def login(self):
        self.root.current = "app"

    def clear(self):
        self.root.ids.user.text = ""
        self.root.ids.password.text = ""


if __name__ == '__main__':
    sm = ScreenManager()
    sm.add_widget(LoginScreen(name='login'))
    sm.add_widget(AppScreen(name='app'))
    sm.add_widget(PDFScreen(name='viewer'))

    MainApp().run()
